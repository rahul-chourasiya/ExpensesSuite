'use client';
import React from 'react';
import { Box, Container, Typography, Grid, Card, CardContent, Paper, Chip } from '@mui/material';
import { motion } from 'framer-motion';
import Head from 'next/head';

// Icons
import ReceiptIcon from '@mui/icons-material/Receipt';
import ApprovalIcon from '@mui/icons-material/Approval';
import TimelineIcon from '@mui/icons-material/Timeline';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import PhoneIphoneIcon from '@mui/icons-material/PhoneIphone';
import AnalyticsIcon from '@mui/icons-material/Analytics';
import RocketLaunchIcon from '@mui/icons-material/RocketLaunch';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import SecurityIcon from '@mui/icons-material/Security';
import SpeedIcon from '@mui/icons-material/Speed';
import IntegrationInstructionsIcon from '@mui/icons-material/IntegrationInstructions';
import CloudSyncIcon from '@mui/icons-material/CloudSync';

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2
    }
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.6,
      ease: "easeOut"
    }
  },
};

const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8, ease: "easeOut" }
  }
};

const heroVariants = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 1, ease: "easeOut" }
  }
};

export default function Features() {
  const featureData = [
    {
      title: 'OCR Receipt Scanning',
      icon: <ReceiptIcon sx={{ fontSize: '2rem' }} />,
      color: '#4E36FF',
      features: [
        'High-accuracy receipt scanning with AI',
        'Automatic categorization of expenses',
        'Multi-format receipt support',
        'Error detection and correction',
        'Real-time data extraction'
      ],
      highlights: ['AI-Powered', 'Accurate', 'Automated']
    },
    {
      title: 'Approval Workflows',
      icon: <ApprovalIcon sx={{ fontSize: '2rem' }} />,
      color: '#FF6B6B',
      features: [
        'Customizable multi-level approval processes',
        'Automated routing to approvers',
        'Approval hierarchy management',
        'Audit trails for compliance',
        'Real-time approval status tracking'
      ],
      highlights: ['Customizable', 'Automated', 'Compliant']
    },
    {
      title: 'Real-Time Tracking',
      icon: <TimelineIcon sx={{ fontSize: '2rem' }} />,
      color: '#10B981',
      features: [
        'Live expense and budget dashboards',
        'Real-time spending alerts',
        'Customizable spending insights',
        'Historical trend analysis',
        'Mobile access to tracking'
      ],
      highlights: ['Real-Time', 'Insightful', 'Mobile']
    },
    {
      title: 'Accounting Integration',
      icon: <AccountBalanceIcon sx={{ fontSize: '2rem' }} />,
      color: '#8B5CF6',
      features: [
        'Seamless sync with QuickBooks',
        'Integration with Xero and other platforms',
        'Automated data export',
        'API support for custom integrations',
        'Secure data transfer'
      ],
      highlights: ['Seamless', 'Secure', 'Automated']
    },
    {
      title: 'Mobile App',
      icon: <PhoneIphoneIcon sx={{ fontSize: '2rem' }} />,
      color: '#F59E0B',
      features: [
        'Receipt uploads on the go',
        'Real-time expense submission',
        'Offline mode functionality',
        'Secure access with biometrics',
        'Push notifications for updates'
      ],
      highlights: ['Mobile-First', 'Secure', 'Offline']
    },
    {
      title: 'Actionable Analytics',
      icon: <AnalyticsIcon sx={{ fontSize: '2rem' }} />,
      color: '#06B6D4',
      features: [
        'Key expense metrics and trends',
        'Customizable financial reports',
        'Real-time dashboard updates',
        'Predictive budgeting insights',
        'Compliance monitoring'
      ],
      highlights: ['Data-Driven', 'Predictive', 'Customizable']
    },
    {
      title: 'Rapid Deployment',
      icon: <RocketLaunchIcon sx={{ fontSize: '2rem' }} />,
      color: '#EF4444',
      features: [
        '5-minute setup process',
        'User-friendly interface',
        '24/7 customer support',
        'Comprehensive training resources',
        'API documentation for integrations'
      ],
      highlights: ['Quick Setup', '24/7 Support', 'User-Friendly']
    }
  ];

  const additionalFeatures = [
    {
      icon: <AutoAwesomeIcon sx={{ fontSize: '1.5rem' }} />,
      title: 'Smart Automation',
      description: 'Automate expense tracking and approvals to save time'
    },
    {
      icon: <SecurityIcon sx={{ fontSize: '1.5rem' }} />,
      title: 'Enterprise Security',
      description: 'Bank-level security with SOC 2 compliance and encryption'
    },
    {
      icon: <SpeedIcon sx={{ fontSize: '1.5rem' }} />,
      title: 'Lightning Fast',
      description: 'Optimized performance with sub-second response times'
    },
    {
      icon: <IntegrationInstructionsIcon sx={{ fontSize: '1.5rem' }} />,
      title: 'Easy Integration',
      description: 'Connect with 100+ accounting and ERP platforms'
    },
    {
      icon: <CloudSyncIcon sx={{ fontSize: '1.5rem' }} />,
      title: 'Cloud-Native',
      description: 'Scalable cloud infrastructure with 99.9% uptime'
    }
  ];

  return (
    <>
      <Head>
        <title>Features | Expenses Suite - AI-Powered Expense Management</title>
        <meta name="description" content="Explore the powerful features of Expenses Suite, including AI-powered receipt scanning, automated approval workflows, real-time tracking, and seamless accounting integrations." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/logo.svg" />
      </Head>

      <Box sx={{
        minHeight: '100vh',
        position: 'relative',
        background: 'linear-gradient(135deg, #0a0a23 0%, #1a1a40 50%, #2d1b69 100%)',
        color: 'white',
        overflow: 'hidden',
      }}>
        {/* Animated Background Elements */}
        <Box
          sx={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            pointerEvents: 'none',
            zIndex: 0,
          }}
        >
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              style={{
                position: 'absolute',
                width: Math.random() * 8 + 4,
                height: Math.random() * 8 + 4,
                borderRadius: '50%',
                background: `linear-gradient(135deg, #4E36FF 0%, #FF6B6B 100%)`,
                opacity: 0.3,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                x: [0, Math.random() * 200 - 100],
                y: [0, Math.random() * 200 - 100],
                scale: [1, Math.random() + 0.5, 1],
              }}
              transition={{
                duration: 10 + Math.random() * 20,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
        </Box>

        {/* Geometric Shapes */}
        <Box sx={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 0 }}>
          <motion.div
            style={{
              position: 'absolute',
              top: '10%',
              right: '10%',
              width: 60,
              height: 60,
              borderRadius: '50%',
              border: '2px solid rgba(78, 54, 255, 0.3)',
            }}
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          />
          <motion.div
            style={{
              position: 'absolute',
              bottom: '20%',
              left: '5%',
              width: 40,
              height: 40,
              background: 'linear-gradient(45deg, rgba(255, 107, 107, 0.2), rgba(78, 54, 255, 0.2))',
              transform: 'rotate(45deg)',
            }}
            animate={{ rotate: [45, 405] }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          />
        </Box>

        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1, py: 8 }}>
          {/* Hero Section */}
          <motion.div
            variants={heroVariants}
            initial="hidden"
            animate="visible"
          >
            <Box sx={{ textAlign: 'center', mb: 8 }}>
              <Typography
                variant="h2"
                sx={{
                  fontWeight: 700,
                  mb: 3,
                  fontSize: { xs: '2.5rem', sm: '3rem', md: '3.5rem' },
                  background: 'linear-gradient(90deg, #4E36FF, #FF6B6B)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                Powerful Features
              </Typography>
              <Box
                sx={{
                  width: 80,
                  height: 4,
                  background: 'linear-gradient(90deg, #4E36FF, #FF6B6B)',
                  mx: 'auto',
                  borderRadius: '10px',
                  mb: 3
                }}
              />
              <Typography
                variant="h5"
                sx={{
                  maxWidth: 700,
                  mx: 'auto',
                  fontSize: { xs: '1.1rem', sm: '1.3rem' },
                  lineHeight: 1.6,
                  color: 'rgba(255, 255, 255, 0.9)',
                  fontWeight: 300,
                }}
              >
                Streamline your expense management with AI-powered tools designed for modern businesses
              </Typography>
            </Box>
          </motion.div>

          {/* Main Features Grid */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <Grid container spacing={4} sx={{ mb: 8 }} alignItems="stretch">
              {featureData.map((featureGroup, index) => (
                <Grid item xs={12} md={6} key={index} sx={{ display: 'flex' }}>
                  <motion.div variants={itemVariants} style={{ display: 'flex', flex: 1 }}>
                    <Card
                      sx={{
                        flex: 1,
                        display: 'flex',
                        flexDirection: 'column',
                        borderRadius: '20px',
                        background: 'rgba(255, 255, 255, 0.05)',
                        backdropFilter: 'blur(20px)',
                        border: '1px solid rgba(255, 255, 255, 0.1)',
                        overflow: 'hidden',
                        transition: 'all 0.3s ease',
                        '&:hover': {
                          transform: 'translateY(-8px)',
                          boxShadow: `0 20px 40px rgba(${featureGroup.color === '#4E36FF' ? '78, 54, 255' : featureGroup.color === '#FF6B6B' ? '255, 107, 107' : featureGroup.color === '#10B981' ? '16, 185, 129' : featureGroup.color === '#8B5CF6' ? '139, 92, 246' : featureGroup.color === '#F59E0B' ? '245, 158, 11' : featureGroup.color === '#06B6D4' ? '6, 182, 212' : '239, 68, 68'}, 0.2)`,
                        }
                      }}
                    >
                      {/* Card Header */}
                      <Box
                        sx={{
                          background: `linear-gradient(135deg, ${featureGroup.color}20 0%, ${featureGroup.color}10 100%)`,
                          p: 3,
                          borderBottom: `1px solid ${featureGroup.color}30`,
                        }}
                      >
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                          <Box
                            sx={{
                              color: featureGroup.color,
                              background: `${featureGroup.color}20`,
                              borderRadius: '12px',
                              p: 1.5,
                              mr: 2,
                            }}
                          >
                            {featureGroup.icon}
                          </Box>
                          <Typography
                            variant="h5"
                            sx={{
                              color: featureGroup.color,
                              fontWeight: 600,
                              fontSize: '1.4rem'
                            }}
                          >
                            {featureGroup.title}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                          {featureGroup.highlights.map((highlight, idx) => (
                            <Chip
                              key={idx}
                              label={highlight}
                              size="small"
                              sx={{
                                background: `${featureGroup.color}20`,
                                color: featureGroup.color,
                                border: `1px solid ${featureGroup.color}40`,
                                fontSize: '0.75rem',
                                fontWeight: 500,
                              }}
                            />
                          ))}
                        </Box>
                      </Box>

                      {/* Card Content */}
                      <CardContent sx={{ p: 3, flex: 1, display: 'flex', flexDirection: 'column' }}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, flex: 1 }}>
                          {featureGroup.features.map((feature, idx) => (
                            <motion.div
                              key={idx}
                              whileHover={{ x: 4 }}
                              transition={{ type: 'spring', stiffness: 300 }}
                            >
                              <Box
                                sx={{
                                  display: 'flex',
                                  alignItems: 'flex-start',
                                  p: 1.5,
                                  borderRadius: '10px',
                                  background: 'rgba(255, 255, 255, 0.03)',
                                  border: '1px solid rgba(255, 255, 255, 0.05)',
                                  transition: 'all 0.2s ease',
                                  '&:hover': {
                                    background: 'rgba(255, 255, 255, 0.05)',
                                  }
                                }}
                              >
                                <Box
                                  sx={{
                                    width: 6,
                                    height: 6,
                                    borderRadius: '50%',
                                    background: featureGroup.color,
                                    mt: 0.75,
                                    mr: 2,
                                    flexShrink: 0,
                                  }}
                                />
                                <Typography
                                  sx={{
                                    fontSize: '0.95rem',
                                    lineHeight: 1.5,
                                    color: 'rgba(255, 255, 255, 0.9)',
                                  }}
                                >
                                  {feature}
                                </Typography>
                              </Box>
                            </motion.div>
                          ))}
                        </Box>
                      </CardContent>
                    </Card>
                  </motion.div>
                </Grid>
              ))}
            </Grid>
          </motion.div>

          {/* Additional Features Section */}
          <motion.div
            variants={fadeInUp}
            initial="hidden"
            animate="visible"
          >
            <Box sx={{ textAlign: 'center', mb: 6 }}>
              <Typography
                variant="h3"
                sx={{
                  fontWeight: 600,
                  mb: 2,
                  fontSize: { xs: '2rem', sm: '2.5rem' },
                  color: 'white',
                }}
              >
                Why Choose Expenses Suite?
              </Typography>
              <Typography
                variant="body1"
                sx={{
                  maxWidth: 600,
                  mx: 'auto',
                  fontSize: '1.1rem',
                  lineHeight: 1.6,
                  color: 'rgba(255, 255, 255, 0.8)',
                }}
              >
                Built for modern businesses with enterprise-grade expense management features
              </Typography>
            </Box>

            <Grid container spacing={3}>
              {additionalFeatures.map((feature, index) => (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <motion.div
                    variants={itemVariants}
                    whileHover={{ scale: 1.05 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Paper
                      sx={{
                        p: 3,
                        height: '100%',
                        borderRadius: '16px',
                        background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.05) 100%)',
                        backdropFilter: 'blur(20px)',
                        border: '1px solid rgba(255, 255, 255, 0.1)',
                        textAlign: 'center',
                        transition: 'all 0.3s ease',
                        '&:hover': {
                          borderColor: 'rgba(78, 54, 255, 0.3)',
                          boxShadow: '0 8px 32px rgba(78, 54, 255, 0.15)',
                        }
                      }}
                    >
                      <Box
                        sx={{
                          color: '#4E36FF',
                          background: 'rgba(78, 54, 255, 0.1)',
                          borderRadius: '12px',
                          width: 48,
                          height: 48,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          mx: 'auto',
                          mb: 2,
                        }}
                      >
                        {feature.icon}
                      </Box>
                      <Typography
                        variant="h6"
                        sx={{
                          fontWeight: 600,
                          mb: 1,
                          color: 'white',
                          fontSize: '1.1rem'
                        }}
                      >
                        {feature.title}
                      </Typography>
                      <Typography
                        variant="body2"
                        sx={{
                          color: 'rgba(255, 255, 255, 0.7)',
                          fontSize: '0.9rem',
                          lineHeight: 1.5,
                        }}
                      >
                        {feature.description}
                      </Typography>
                    </Paper>
                  </motion.div>
                </Grid>
              ))}
            </Grid>
          </motion.div>

          {/* CTA Section */}
          <motion.div
            variants={fadeInUp}
            initial="hidden"
            animate="visible"
          >
            <Box sx={{ textAlign: 'center', mt: 10, mb: 4 }}>
              <Paper
                sx={{
                  p: 6,
                  borderRadius: '24px',
                  background: 'linear-gradient(135deg, rgba(78, 54, 255, 0.15) 0%, rgba(255, 107, 107, 0.15) 100%)',
                  backdropFilter: 'blur(20px)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                }}
              >
                <Typography
                  variant="h4"
                  sx={{
                    fontWeight: 600,
                    mb: 2,
                    background: 'linear-gradient(90deg, #4E36FF, #FF6B6B)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  Ready to Transform Your Expense Management?
                </Typography>
                <Typography
                  variant="body1"
                  sx={{
                    maxWidth: 500,
                    mx: 'auto',
                    mb: 3,
                    color: 'rgba(255, 255, 255, 0.8)',
                    fontSize: '1.1rem',
                    lineHeight: 1.6,
                  }}
                >
                  Join thousands of companies using Expenses Suite to automate expense tracking and reimbursements
                </Typography>
                <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    style={{
                      background: 'linear-gradient(135deg, #4E36FF 0%, #FF6B6B 100%)',
                      border: 'none',
                      borderRadius: '12px',
                      padding: '12px 24px',
                      color: 'white',
                      fontWeight: 600,
                      fontSize: '1rem',
                      cursor: 'pointer',
                      boxShadow: '0 4px 15px rgba(78, 54, 255, 0.3)',
                    }}
                  >
                    Start Free Trial
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    style={{
                      background: 'transparent',
                      border: '2px solid rgba(255, 255, 255, 0.3)',
                      borderRadius: '12px',
                      padding: '10px 24px',
                      color: 'white',
                      fontWeight: 600,
                      fontSize: '1rem',
                      cursor: 'pointer',
                    }}
                  >
                    Schedule Demo
                  </motion.button>
                </Box>
              </Paper>
            </Box>
          </motion.div>
        </Container>
      </Box>
    </>
  );
}