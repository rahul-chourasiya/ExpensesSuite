'use client';
import { Inter } from 'next/font/google';
import './globals.css';
import { ThemeProvider } from '@mui/material/styles';
import theme from './theme/theme';
import CssBaseline from '@mui/material/CssBaseline';
import { AppRouterCacheProvider } from '@mui/material-nextjs/v14-appRouter';
import Navbar from '@/components/common/Navbar';
import Footer from '@/components/common/Footer';
import Script from 'next/script'; // Import Script from next/script

const inter = Inter({ subsets: ['latin'] });

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AppRouterCacheProvider>
          <ThemeProvider theme={theme}>
            <CssBaseline />
              <Navbar />
              {children}
              <Footer />
          </ThemeProvider>
        </AppRouterCacheProvider>


        {/* <Script id="zoho-salesiq-init" strategy="afterInteractive">
          {`window.$zoho=window.$zoho || {};$zoho.salesiq=$zoho.salesiq||{ready:function(){}}`}
        </Script>

   
        <Script
          id="zsiqscript"
          src="https://salesiq.zohopublic.in/widget?wc=siq0b9ea56d740fe96b2f7dfcde2558464f461eb9ba83787616e45b1912179acb13"
          strategy="afterInteractive"
          defer
        /> */}
      </body>
    </html>
  );
}