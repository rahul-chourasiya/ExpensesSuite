'use client';
import { Box, Container, Grid, Typography, Card, CardContent } from '@mui/material';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import { motion } from 'framer-motion';

const features = [
  {
    title: "OCR Receipt Scanning",
    description: "Automate receipt processing with OCR technology for accurate categorization and data extraction."
  },
  {
    title: "Multi-level Approval Workflows",
    description: "Streamline approvals with customizable, multi-tiered workflows tailored to your organization."
  },
  {
    title: "Real-time Expense Tracking",
    description: "Monitor expenses and budgets in real-time to maintain financial control and transparency."
  },
  {
    title: "Accounting Software Integration",
    description: "Seamlessly connect with popular accounting platforms for unified financial management."
  },
  {
    title: "Mobile App Access",
    description: "Manage expenses on-the-go with our intuitive mobile app for iOS and Android."
  }
];

const commonGradients = [
  'linear-gradient(135deg, #4E36FF 0%, #7C3AED 100%)',
  'linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%)',
  'linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%)',
  'linear-gradient(135deg, #45B7D1 0%, #2196F3 100%)',
  'linear-gradient(135deg, #F7931E 0%, #FF9800 100%)',
  'linear-gradient(135deg, #96CEB4 0%, #4CAF50 100%)',
  'linear-gradient(135deg, #D63384 0%, #E91E63 100%)',
  'linear-gradient(135deg, #20C997 0%, #17A2B8 100%)',
];

const ChooseUsSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" }
    }
  };
  
  const headingVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.7, ease: "easeOut" }
    }
  };
  
  const ctaCardVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { duration: 0.8, ease: "easeOut", delay: 0.4 }
    }
  };
  
  const bgPatternVariants = {
    animate: {
      rotate: 360,
      transition: { duration: 40, ease: "linear", repeat: Infinity }
    }
  };
  
  const floatingBubblesVariants = {
    animate: {
      y: [0, -15, 0],
      transition: { duration: 5, ease: "easeInOut", repeat: Infinity }
    }
  };

  return (
    <Box 
      id="services" 
      sx={{ 
        py: { xs: 8, md: 12 },
        background: 'linear-gradient(135deg, #0a0a23 0%, #1a1a40 50%, #2d1b69 100%)',
        color: 'white',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          pointerEvents: 'none',
          zIndex: 0
        }}
      >
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            style={{
              position: 'absolute',
              width: Math.random() * 8 + 4,
              height: Math.random() * 8 + 4,
              borderRadius: '50%',
              background: commonGradients[i % commonGradients.length],
              opacity: 0.3,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              x: [0, Math.random() * 200 - 100],
              y: [0, Math.random() * 200 - 100],
              scale: [1, Math.random() + 0.5, 1],
            }}
            transition={{
              duration: 10 + Math.random() * 20,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        ))}
      </Box>

      <Box sx={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, overflow: 'hidden' }}>
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            variants={floatingBubblesVariants}
            animate="animate"
            custom={i}
            style={{
              position: 'absolute',
              width: `${30 + Math.random() * 70}px`,
              height: `${30 + Math.random() * 70}px`,
              borderRadius: '50%',
              background: 'rgba(78, 54, 255, 0.05)',
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              zIndex: 0
            }}
          />
        ))}
      </Box>
      
      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={containerVariants}
        >
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <motion.div variants={headingVariants}>
              <Typography 
                variant="h2" 
                fontWeight="bold" 
                sx={{ 
                  mb: 3,
                  background: 'linear-gradient(135deg, #4E36FF 0%, #900BFF 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                Why Choose Expenses Suite?
              </Typography>
            </motion.div>
            
            <motion.div variants={itemVariants}>
              <Typography 
                variant="body1" 
                color="rgba(255, 255, 255, 0.8)" 
                sx={{ 
                  maxWidth: '800px',
                  mx: 'auto'
                }}
              >
                Expenses Suite offers a comprehensive set of tools to simplify and automate your expense management, saving time, reducing errors, and enhancing financial control.
              </Typography>
            </motion.div>
          </Box>
          
          <Grid container spacing={4}>
            {features.map((feature, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <motion.div
                  variants={itemVariants}
                  whileHover={{ 
                    y: -15,
                    boxShadow: '0 20px 40px rgba(78, 54, 255, 0.15)',
                    transition: { duration: 0.3 } 
                  }}
                >
                  <Card 
                    elevation={0}
                    sx={{ 
                      height: '300px',
                      borderRadius: 3,
                      overflow: 'hidden',
                      border: '1px solid rgba(255,255,255,0.1)',
                      background: 'rgba(255, 255, 255, 0.05)',
                      backdropFilter: 'blur(20px)',
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        borderColor: 'primary.main',
                        borderRadius: 3,
                      }
                    }}
                  >
                    <CardContent sx={{ p: 4 }}>
                      <Box 
                        sx={{ 
                          display: 'flex', 
                          alignItems: 'center', 
                          mb: 2,
                          color: 'primary.main'
                        }}
                      >
                        <motion.div
                          whileHover={{ rotate: 360 }}
                          transition={{ duration: 0.5 }}
                        >
                          <CheckCircleOutlineIcon sx={{ mr: 1, fontSize: 28 }} />
                        </motion.div>
                        <Typography variant="h5" fontWeight="bold" color="white">
                          {feature.title}
                        </Typography>
                      </Box>
                      <Typography variant="body1" color="rgba(255, 255, 255, 0.8)">
                        {feature.description}
                      </Typography>
                    </CardContent>
                  </Card>
                </motion.div>
              </Grid>
            ))}
          </Grid>
          
          <Box sx={{ mt: 10 }}>
            <motion.div
              variants={ctaCardVariants}
              whileHover={{ 
                scale: 1.02,
                transition: { duration: 0.3 }
              }}
            >
              <Card 
                elevation={0}
                sx={{ 
                  borderRadius: 4,
                  overflow: 'hidden',
                  background: 'linear-gradient(135deg, #4E36FF 0%, #900BFF 100%)',
                  position: 'relative'
                }}
              >
                <Box sx={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', overflow: 'hidden' }}>
                  <motion.div
                    variants={bgPatternVariants}
                    animate="animate"
                    style={{
                      width: '140%',
                      height: '140%',
                      backgroundColor: 'rgba(255,255,255,0.03)',
                      backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px)',
                      backgroundSize: '20px 20px',
                      borderRadius: '50%',
                      position: 'absolute',
                      zIndex: 1,
                    }}
                  />
                  
                  {[...Array(3)].map((_, i) => (
                    <motion.div
                      key={i}
                      animate={{ 
                        x: [0, 20, 0],
                        y: [0, 15, 0],
                      }}
                      transition={{
                        duration: 5 + i * 2,
                        ease: "easeInOut",
                        repeat: Infinity,
                        repeatType: "reverse"
                      }}
                      style={{
                        position: 'absolute',
                        width: `${100 + i * 50}px`,
                        height: `${100 + i * 50}px`,
                        borderRadius: '50%',
                        background: 'rgba(255,255,255,0.05)',
                        right: `${-50 + i * 20}px`,
                        top: `${50 + i * 40}px`,
                        zIndex: 0
                      }}
                    />
                  ))}
                </Box>
                
                <Grid container sx={{ position: 'relative', zIndex: 2 }}>
                  <Grid item xs={12} md={7}>
                    <CardContent sx={{ p: { xs: 4, md: 6 }, color: 'white' }}>
                      <Typography variant="h3" fontWeight="bold" sx={{ mb: 3 }}>
                        Streamline Your Finances Today
                      </Typography>
                      <Typography variant="h6" sx={{ mb: 4, opacity: 0.9 }}>
                        Discover how Expenses Suite can transform your expense management with automation and real-time insights.
                      </Typography>
                      <motion.div
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        transition={{ duration: 0.2 }}
                      >
                        <Box 
                          component="button"
                          sx={{
                            backgroundColor: 'white',
                            color: 'primary.main',
                            border: 'none',
                            borderRadius: 2,
                            py: 1.5,
                            px: 4,
                            fontSize: 16,
                            fontWeight: 'bold',
                            cursor: 'pointer',
                            transition: 'all 0.3s ease',
                            position: 'relative',
                            overflow: 'hidden',
                            '&:hover': {
                              boxShadow: '0 10px 25px rgba(0,0,0,0.2)',
                            }
                          }}
                          onClick={() => window.location.href = '#contact'}
                        >
                          <motion.div
                            initial={{ x: '-100%' }}
                            whileHover={{ x: '100%' }}
                            transition={{ duration: 0.5, ease: "easeInOut" }}
                            style={{
                              position: 'absolute',
                              top: 0,
                              left: 0,
                              width: '100%',
                              height: '100%',
                              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)',
                              zIndex: 1
                            }}
                          />
                          <Box sx={{ position: 'relative', zIndex: 2 }}>
                            Get Started Today
                          </Box>
                        </Box>
                      </motion.div>
                    </CardContent>
                  </Grid>
                  <Grid 
                    item 
                    xs={12} 
                    md={5}
                    sx={{
                      display: { xs: 'none', md: 'block' },
                      position: 'relative',
                    }}
                  >
                    <Box 
                      sx={{ 
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        overflow: 'hidden',
                      }}
                    >
                      <motion.div
                        animate={{ 
                          rotate: 360,
                          scale: [1, 1.05, 1]
                        }}
                        transition={{
                          rotate: { duration: 20, ease: "linear", repeat: Infinity },
                          scale: { duration: 8, ease: "easeInOut", repeat: Infinity }
                        }}
                        style={{
                          width: '140%',
                          height: '140%',
                          backgroundColor: 'rgba(255,255,255,0.03)',
                          backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px)',
                          backgroundSize: '20px 20px',
                          borderRadius: '50%',
                          position: 'absolute',
                          zIndex: 1,
                        }}
                      />
                      <Box
                        sx={{
                          position: 'relative',
                          zIndex: 2,
                          width: '80%',
                          height: '80%',
                        }}
                      />
                    </Box>
                  </Grid>
                </Grid>
              </Card>
            </motion.div>
          </Box>
        </motion.div>
      </Container>
    </Box>
  );
};

export default ChooseUsSection;