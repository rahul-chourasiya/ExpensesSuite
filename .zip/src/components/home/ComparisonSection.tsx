'use client';
import { Box, Container, Grid, Typography, Card, CardContent, Divider } from '@mui/material';
import FadeIn from '../animations/FadeIn';
import GradientText from '../ui/GradientText';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import WorkIcon from '@mui/icons-material/Work';
import SmartToyIcon from '@mui/icons-material/SmartToy';
import { motion } from 'framer-motion';

const comparisonData = [
  {
    task: "Approvals from Respective Authority",
    manual: "Each person will recommend manually as per his convenience to higher Authority",
    ai: "AI will Identify the concerned Authority as per your matrix and will send the approval directly to him"
  },
  {
    task: "Follow Ups / Reminder Mails",
    manual: "Manual way of doing follow ups, with no measurement or tracking of delay",
    ai: "Set your TAT of reminders and calculate who is delaying the approval"
  },
  {
    task: "Compliance Clearance",
    manual: "Depends upon Human intelligence, which may sometime missed any critical point",
    ai: "Prepare the check list at one go and generate the report of 100% compliance check any time at a click of a button"
  },
  {
    task: "Document Verification",
    manual: "Employees manually verify each document, which increases the risk of human errors and delays",
    ai: "AI will instantly validate documents against predefined criteria and flag discrepancies automatically"
  },
  {
    task: "Task Delegation & Tracking",
    manual: "Managers manually assign tasks, track progress, and follow up, leading to inefficiencies",
    ai: "AI will auto-assign tasks based on workload and skill set, while also tracking real-time progress"
  },
  {
    task: "Report Generation",
    manual: "Reports are manually compiled, taking hours or even days, with a risk of errors",
    ai: "AI generates instant, accurate reports with insights and analytics at a click"
  },
  {
    task: "Customer Query Handling",
    manual: "Support teams respond manually to customer queries, leading to delays and inconsistencies",
    ai: "AI chatbot handles queries instantly, provides relevant solutions, and escalates complex issues"
  }
];

const commonGradients = [
  'linear-gradient(135deg, #4E36FF 0%, #7C3AED 100%)',
  'linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%)',
  'linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%)',
  'linear-gradient(135deg, #45B7D1 0%, #2196F3 100%)',
  'linear-gradient(135deg, #F7931E 0%, #FF9800 100%)',
  'linear-gradient(135deg, #96CEB4 0%, #4CAF50 100%)',
  'linear-gradient(135deg, #D63384 0%, #E91E63 100%)',
  'linear-gradient(135deg, #20C997 0%, #17A2B8 100%)',
];

const ComparisonSection = () => {
  return (
    <Box 
      sx={{ 
        py: { xs: 8, md: 12 },
        background: 'linear-gradient(135deg, #0a0a23 0%, #1a1a40 50%, #2d1b69 100%)',
        color: 'white',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      {/* Animated Background Elements */}
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          pointerEvents: 'none',
          zIndex: 0
        }}
      >
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            style={{
              position: 'absolute',
              width: Math.random() * 8 + 4,
              height: Math.random() * 8 + 4,
              borderRadius: '50%',
              background: commonGradients[i % commonGradients.length],
              opacity: 0.3,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              x: [0, Math.random() * 200 - 100],
              y: [0, Math.random() * 200 - 100],
              scale: [1, Math.random() + 0.5, 1],
            }}
            transition={{
              duration: 10 + Math.random() * 20,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        ))}
      </Box>
   <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Box sx={{ textAlign: 'center', mb: 8 }}>
          <FadeIn>
            <GradientText variant="h2" fontWeight="bold" sx={{ mb: 3 }}>
              Manual vs. Automated Expense Management
            </GradientText>
            <Typography 
              variant="body1" 
              color="rgba(255, 255, 255, 0.8)" 
              sx={{ 
                maxWidth: '800px',
                mx: 'auto'
              }}
            >
              Compare traditional manual processes with the efficiency and accuracy of Expenses Suite's automation.
            </Typography>

            <Typography 
              variant="h6" 
              fontWeight="bold"
              color="primary.main"
              sx={{ mt: 5 }}
            >
              AUTOMATED VS MANUAL METHODS
            </Typography>

            <Typography 
              variant="body1" 
              color="rgba(255, 255, 255, 0.8)" 
              sx={{ 
                maxWidth: '800px',
                mx: 'auto'
              }}
            >
              See how Expenses Suite transforms expense management tasks.
            </Typography>
          </FadeIn>
        </Box>
        
        <Grid container spacing={4}>
          <Grid item xs={12}>
            <FadeIn>
              <Card 
                elevation={0}
                sx={{ 
                  borderRadius: 4,
                  border: '1px solid rgba(255,255,255,0.1)',
                  overflow: 'hidden',
                  background: 'rgba(255, 255, 255, 0.05)',
                  backdropFilter: 'blur(20px)'
                }}
              >
                <Box sx={{ p: 2, bgcolor: 'rgba(255, 255, 255, 0.03)' }}>
                  <Grid container>
                    <Grid item xs={12} sm={4}>
                      <Typography variant="h6" fontWeight="bold" sx={{ p: 2, color: 'white' }}>
                        <CompareArrowsIcon sx={{ mr: 1, verticalAlign: 'middle', color: 'primary.main' }} />
                        Activity / Task
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <Typography variant="h6" fontWeight="bold" sx={{ p: 2, color: 'white' }}>
                        <WorkIcon sx={{ mr: 1, verticalAlign: 'middle', color: 'error.main' }} />
                        Manual Approach
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <Typography variant="h6" fontWeight="bold" sx={{ p: 2, color: 'white' }}>
                        <SmartToyIcon sx={{ mr: 1, verticalAlign: 'middle', color: 'primary.main' }} />
                        Automated Approach
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>
                
                <Divider sx={{ borderColor: 'rgba(255,255,255,0.1)' }} />
                
                {comparisonData.map((item, index) => (
                  <Box key={index}>
                    <Grid container>
                      <Grid item xs={12} sm={4}>
                        <Box 
                          sx={{ 
                            p: 3,
                            height: '100%',
                            display: 'flex',
                            alignItems: 'center',
                            borderRight: { xs: 'none', sm: '1px solid rgba(255,255,255,0.1)' },
                            borderBottom: { xs: '1px solid rgba(255,255,255,0.1)', sm: 'none' }
                          }}
                        >
                          <Typography variant="body1" fontWeight="medium" color="white">
                            {index + 1}. {item.task}
                          </Typography>
                        </Box>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <Box 
                          sx={{ 
                            p: 3,
                            height: '100%',
                            display: 'flex',
                            alignItems: 'center',
                            borderRight: { xs: 'none', sm: '1px solid rgba(255,255,255,0.1)' },
                            borderBottom: { xs: '1px solid rgba(255,255,255,0.1)', sm: 'none' },
                            bgcolor: 'rgba(211, 47, 47, 0.05)'
                          }}
                        >
                          <Typography variant="body2" color="rgba(255, 255, 255, 0.7)">
                            {item.manual}
                          </Typography>
                        </Box>
                      </Grid>
                      <Grid item xs={12} sm={4}>
                        <Box 
                          sx={{ 
                            p: 3,
                            height: '100%',
                            display: 'flex',
                            alignItems: 'center',
                            bgcolor: 'rgba(78, 54, 255, 0.05)'
                          }}
                        >
                          <Typography variant="body2" color="white" fontWeight="medium">
                            {item.ai}
                          </Typography>
                        </Box>
                      </Grid>
                    </Grid>
                    {index < comparisonData.length - 1 && <Divider sx={{ borderColor: 'rgba(255,255,255,0.1)' }} />}
                  </Box>
                ))}
              </Card>
            </FadeIn>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default ComparisonSection;