'use client';
import { Box, Container, Grid, Typography, Card, CardContent } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { motion } from 'framer-motion';
import SectionTransition from '../animations/SectionTransition';
import TextSplitReveal from '../animations/TextSplitReveal';
import MorphingShape from '../animations/MorphingShape';
import FloatingElement from '../animations/FloatingElement';
import AnimatedCounter from '../animations/AnimatedCounter';

const commonGradients = [
  'linear-gradient(135deg, #4E36FF 0%, #7C3AED 100%)',
  'linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%)',
  'linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%)',
  'linear-gradient(135deg, #45B7D1 0%, #2196F3 100%)',
  'linear-gradient(135deg, #F7931E 0%, #FF9800 100%)',
  'linear-gradient(135deg, #96CEB4 0%, #4CAF50 100%)',
  'linear-gradient(135deg, #D63384 0%, #E91E63 100%)',
  'linear-gradient(135deg, #20C997 0%, #17A2B8 100%)',
];

const EnhancedAboutSection = () => {
  const theme = useTheme();

  return (
    <Box 
      id="about" 
      sx={{ 
        py: { xs: 10, md: 14 },
        background: 'linear-gradient(135deg, #0a0a23 0%, #1a1a40 50%, #2d1b69 100%)',
        color: 'white',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          pointerEvents: 'none',
          zIndex: 0
        }}
      >
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            style={{
              position: 'absolute',
              width: Math.random() * 8 + 4,
              height: Math.random() * 8 + 4,
              borderRadius: '50%',
              background: commonGradients[i % commonGradients.length],
              opacity: 0.3,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              x: [0, Math.random() * 200 - 100],
              y: [0, Math.random() * 200 - 100],
              scale: [1, Math.random() + 0.5, 1],
            }}
            transition={{
              duration: 10 + Math.random() * 20,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        ))}
      </Box>

      <Box sx={{ position: 'absolute', right: '-5%', bottom: '-5%', zIndex: 0, opacity: 0.15 }}>
        <MorphingShape
          color={theme.palette.primary.light}
          secondaryColor={theme.palette.secondary.light}
          size={300}
          speed={15}
        />
      </Box>
      
      <Box sx={{ position: 'absolute', left: '-8%', top: '20%', zIndex: 0, opacity: 0.1 }}>
        <MorphingShape
          color={theme.palette.secondary.main}
          secondaryColor={theme.palette.primary.main}
          size={350}
          speed={18}
        />
      </Box>
      
      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Grid container spacing={8} alignItems="center">
          <Grid item xs={12} md={6}>
            <SectionTransition direction="left">
              <Typography 
                variant="h6" 
                fontWeight="bold"
                color="primary.main"
                sx={{ mb: 2 }}
              >
                ABOUT US
              </Typography>
              
              <TextSplitReveal
                text="Transform Your Expense Management"
                variant="h2"
                fontWeight="bold" 
                splitBy="words"
                effect="slide"
                sx={{ 
                  mb: 3,
                  background: `linear-gradient(90deg, ${theme.palette.primary.main} 0%, ${theme.palette.secondary.main} 100%)`,
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              />
              
              <Typography variant="body1" color="rgba(255, 255, 255, 0.8)" sx={{ mb: 4 }}>
                Expenses Suite is a cutting-edge solution designed to streamline your financial processes. Our smart expense management system automates tracking, approval workflows, and reimbursement processes, ensuring efficiency and accuracy.
              </Typography>
              
              <Grid container spacing={3} sx={{ mb: 5 }}>
                <Grid item xs={4}>
                  <SectionTransition.Item delay={0.1}>
                    <Card elevation={0} sx={{ background: 'rgba(255, 255, 255, 0.05)', p: 2, borderRadius: 3, border: '1px solid rgba(255,255,255,0.1)' }}>
                      <AnimatedCounter
                        end={90}
                        suffix="%"
                        variant="h4"
                        color="primary.main"
                        fontWeight="bold"
                        duration={2.5}
                      />
                      <Typography variant="body2" color="rgba(255, 255, 255, 0.7)">
                        Faster reimbursement processing
                      </Typography>
                    </Card>
                  </SectionTransition.Item>
                </Grid>
                
                <Grid item xs={4}>
                  <SectionTransition.Item delay={0.2}>
                    <Card elevation={0} sx={{ background: 'rgba(255, 255, 255, 0.05)', p: 2, borderRadius: 3, border: '1px solid rgba(255,255,255,0.1)' }}>
                      <AnimatedCounter
                        end={95}
                        suffix="%"
                        variant="h4"
                        color="primary.main"
                        fontWeight="bold"
                        duration={2.5}
                      />
                      <Typography variant="body2" color="rgba(255, 255, 255, 0.7)">
                        Accuracy in expense tracking
                      </Typography>
                    </Card>
                  </SectionTransition.Item>
                </Grid>
                
                <Grid item xs={4}>
                  <SectionTransition.Item delay={0.3}>
                    <Card elevation={0} sx={{ background: 'rgba(255, 255, 255, 0.05)', p: 2, borderRadius: 3, border: '1px solid rgba(255,255,255,0.1)' }}>
                      <Typography variant="h4" color="primary.main" fontWeight="bold">
                        24/7
                      </Typography>
                      <Typography variant="body2" color="rgba(255, 255, 255, 0.7)">
                        Mobile access
                      </Typography>
                    </Card>
                  </SectionTransition.Item>
                </Grid>
              </Grid>
              
              <SectionTransition.Item delay={0.4}>
                <Box>
                  <Typography variant="h5" fontWeight="bold" color="white" sx={{ mb: 2 }}>
                    Who We Are
                  </Typography>
                  <Typography variant="body1" color="rgba(255, 255, 255, 0.8)" sx={{ mb: 3 }}>
                    Expenses Suite is developed by a team dedicated to revolutionizing finance and accounting through automation. We focus on delivering intuitive, scalable solutions for businesses of all sizes.
                  </Typography>
                </Box>
              </SectionTransition.Item>
            </SectionTransition>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Grid container spacing={4}>
              <Grid item xs={12}>
                <SectionTransition direction="right" delay={0.2}>
                  <FloatingElement yOffset={10} duration={6}>
                    <Card 
                      elevation={6}
                      sx={{ 
                        borderRadius: 4,
                        overflow: 'visible',
                        background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.secondary.main} 100%)`,
                        color: 'white',
                        position: 'relative',
                        p: 1,
                        boxShadow: `0 20px 40px rgba(${parseInt(theme.palette.primary.main.slice(1, 3), 16)}, ${parseInt(theme.palette.primary.main.slice(3, 5), 16)}, ${parseInt(theme.palette.primary.main.slice(5, 7), 16)}, 0.3)`,
                      }}
                    >
                      <CardContent sx={{ p: 4 }}>
                        <TextSplitReveal
                          text="Mission:"
                          variant="h5"
                          fontWeight="bold"
                          sx={{ mb: 2 }}
                          effect="slide"
                          splitBy="chars"
                        />
                        <Typography variant="body1">
                          To provide businesses with an affordable, easy-to-use expense management system that automates financial processes and enhances operational efficiency.
                        </Typography>
                      </CardContent>
                      <Box
                        component={motion.div}
                        whileHover={{ rotate: 15, scale: 1.1 }}
                        sx={{
                          position: 'absolute',
                          top: -30,
                          right: -20,
                          width: 80,
                          height: 80,
                          bgcolor: 'rgba(255,255,255,0.15)',
                          borderRadius: '50%',
                          backdropFilter: 'blur(8px)',
                          zIndex: -1,
                        }}
                      />
                    </Card>
                  </FloatingElement>
                </SectionTransition>
              </Grid>
              
              <Grid item xs={12}>
                <SectionTransition direction="right" delay={0.4}>
                  <FloatingElement yOffset={10} duration={6} delay={1}>
                    <Card 
                      elevation={3}
                      sx={{ 
                        borderRadius: 4,
                        border: '1px solid rgba(255,255,255,0.1)',
                        position: 'relative',
                        p: 1,
                        background: 'rgba(255, 255, 255, 0.05)',
                        backdropFilter: 'blur(20px)',
                        transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
                        '&:hover': {
                          transform: 'translateY(-5px)',
                          boxShadow: '0 15px 30px rgba(255,255,255,0.1)'
                        }
                      }}
                    >
                      <CardContent sx={{ p: 4 }}>
                        <TextSplitReveal
                          text="Vision:"
                          variant="h5"
                          fontWeight="bold"
                          sx={{ mb: 2, color: 'white' }}
                          effect="slide"
                          splitBy="chars"
                        />
                        <Typography variant="body1" color="rgba(255, 255, 255, 0.8)">
                          To empower organizations with intelligent expense management tools that simplify financial processes, reduce costs, and drive growth.
                        </Typography>
                      </CardContent>
                      <Box
                        component={motion.div}
                        whileHover={{ rotate: -15, scale: 1.1 }}
                        sx={{
                          position: 'absolute',
                          bottom: -20,
                          left: -20,
                          width: 60,
                          height: 60,
                          background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.secondary.main} 100%)`,
                          borderRadius: '50%',
                          opacity: 0.2,
                          zIndex: -1,
                        }}
                      />
                    </Card>
                  </FloatingElement>
                </SectionTransition>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default EnhancedAboutSection;  