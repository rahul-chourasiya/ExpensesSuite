'use client';
import { useState, useEffect } from "react";
import {
  Box,
  Container,
  Grid,
  Typography,
  Button,
  useTheme,
} from "@mui/material";
import { motion } from "framer-motion";
import AnimatedButton from "../ui/AnimatedButton";
import TextSplitReveal from "../animations/TextSplitReveal";
import ParticleBackground from "../animations/ParticleBackground";
import TextGlitch from "../animations/TextGlitch";
import DemoRequestModal from "../common/DemoRequestModal";

const EnhancedHeroSection = () => {
  const theme = useTheme();
  const [isMounted, setIsMounted] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const handleOpenDemoModal = () => {
    setIsDemoModalOpen(true);
  };

  const handleCloseDemoModal = () => {
    setIsDemoModalOpen(false);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.4, 0.0, 0.2, 1],
      },
    },
  };

  return (
    <Box
      className="hero-section"
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        pt: 12,
        pb: 8,
        position: "relative",
        overflow: "hidden",
      }}
    >
      <ParticleBackground
        count={30}
        colors={[
          theme.palette.primary.main,
          theme.palette.primary.light,
          theme.palette.secondary.main,
          theme.palette.secondary.light,
        ]}
        speed={0.3}
        minSize={1}
        maxSize={3}
        style={{ opacity: 0.5 }}
      />

      <Container maxWidth="xl" sx={{ position: "relative", zIndex: 1 }}>
        <motion.div
          initial="hidden"
          animate={isVisible ? "visible" : "hidden"}
          variants={containerVariants}
        >
          <Grid container spacing={4} alignItems="center" justifyContent="center">
            <Grid item xs={12} md={12}>
              <Box sx={{ position: "relative", zIndex: 2, textAlign: "center" }}>
                <motion.div variants={itemVariants}>
                  <Typography
                    variant="body1"
                    color="primary.main"
                    fontWeight="bold"
                    sx={{
                      mb: 1,
                      textTransform: "uppercase",
                      letterSpacing: 1.5,
                      display: "inline-block",
                      background: `linear-gradient(90deg, ${theme.palette.primary.main} 0%, ${theme.palette.secondary.main} 100%)`,
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                    }}
                  >
                    Finance & Accounting
                  </Typography>
                </motion.div>

                <motion.div variants={itemVariants}>
                  <TextSplitReveal
                    text="Expenses Suite"
                    variant="h1"
                    fontWeight="bold"
                    splitBy="words"
                    staggerChildren={0.08}
                    effect="slide"
                    direction="up"
                    sx={{
                      color: "white",
                      mb: 2,
                      fontSize: { xs: "2.5rem", md: "3.5rem" },
                      lineHeight: 1.2,
                    }}
                  />
                </motion.div>

                <motion.div variants={itemVariants}>
                  <TextGlitch
                    text="Automate expense tracking and reimbursement"
                    variant="h5"
                    glitchInterval={5000}
                    glitchDuration={300}
                    sx={{
                      mb: 1,
                      color: "white",
                      opacity: 0.9,
                    }}
                  />
                  <Typography
                    variant="h5"
                    color="white"
                    sx={{
                      mb: 4,
                      opacity: 0.9,
                      maxWidth: "80%",
                      mx: "auto",
                    }}
                  >
                    Smart expense management system that automates tracking, approval workflows, and reimbursement processes.
                  </Typography>
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  style={{ display: "flex", gap: 16, flexWrap: "wrap", justifyContent: "center" }}
                >
                  <AnimatedButton
                    variant="contained"
                    color="primary"
                    size="large"
                    sx={{
                      py: 1.5,
                      px: 4,
                      background: `linear-gradient(90deg, ${theme.palette.primary.main} 0%, ${theme.palette.secondary.main} 100%)`,
                      borderRadius: 2,
                      boxShadow: "0 10px 25px rgba(78, 54, 255, 0.3)",
                    }}
                    hoverScale={1.05}
                    onClick={handleOpenDemoModal}
                  >
                    Book a Free Demo
                  </AnimatedButton>

                  <AnimatedButton
                    variant="outlined"
                    color="primary"
                    size="large"
                    sx={{
                      py: 1.5,
                      px: 4,
                      borderColor: "rgba(255,255,255,0.3)",
                      color: "white",
                      borderWidth: 2,
                      borderRadius: 2,
                      "&:hover": {
                        borderColor: "white",
                        bgcolor: "rgba(255,255,255,0.05)",
                        borderWidth: 2,
                      },
                    }}
                    hoverScale={1.05}
                    href="#about"
                  >
                    Learn More
                  </AnimatedButton>
                </motion.div>
              </Box>
            </Grid>
          </Grid>
        </motion.div>
      </Container>

      <Box
        sx={{
          position: "absolute",
          bottom: 0,
          left: 0,
          width: "100%",
          overflow: "visible",
          height: "30%",
          background:
            "linear-gradient(to top, rgba(15,15,30,0.8) 0%, rgba(15,15,30,0) 100%)",
          zIndex: 0,
        }}
      />

      <DemoRequestModal open={isDemoModalOpen} onClose={handleCloseDemoModal} />
    </Box>
  );
};

export default EnhancedHeroSection;