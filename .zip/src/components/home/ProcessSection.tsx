'use client';
import { Box, Container, Grid, Typography, Card, CardContent, Stepper, Step, StepLabel, StepContent } from '@mui/material';
import FadeIn from '../animations/FadeIn';
import GradientText from '../ui/GradientText';
import { useState, useEffect, useRef } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Link from 'next/link';

const steps = [
  {
    label: 'Expense Process Analysis',
    description: 'We analyze your expense management processes to identify bottlenecks and areas for automation.'
  },
  {
    label: 'Customized Automation Solutions',
    description: 'We design tailored solutions that automate expense tracking, approvals, and reimbursements, aligning with your business needs.'
  },
  {
    label: 'Seamless System Integration',
    description: 'Our solutions integrate with your existing accounting software, ensuring a unified and efficient workflow.'
  },
  {
    label: 'Ongoing Support & Optimization',
    description: 'We provide continuous support and system updates to keep your expense management efficient and up-to-date.'
  }
];

const commonGradients = [
  'linear-gradient(135deg, #4E36FF 0%, #7C3AED 100%)',
  'linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%)',
  'linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%)',
  'linear-gradient(135deg, #45B7D1 0%, #2196F3 100%)',
  'linear-gradient(135deg, #F7931E 0%, #FF9800 100%)',
  'linear-gradient(135deg, #96CEB4 0%, #4CAF50 100%)',
  'linear-gradient(135deg, #D63384 0%, #E91E63 100%)',
  'linear-gradient(135deg, #20C997 0%, #17A2B8 100%)',
];

const ProcessSection = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  
  const { ref, inView } = useInView({
    threshold: 0.2,
    triggerOnce: false
  });
  const controls = useAnimation();

  const handleStepMouseEnter = (index: number) => {
    setIsHovering(true);
    setActiveStep(index);
  };

  const handleStepMouseLeave = () => {
    setIsHovering(false);
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (inView) {
      controls.start("visible");
      
      if (!isHovering) {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
        }
        
        intervalRef.current = setInterval(() => {
          setActiveStep((prevActiveStep) => {
            const nextStep = prevActiveStep + 1;
            return nextStep >= steps.length ? 0 : nextStep;
          });
        }, 3000);
      } else {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      }
    } else {
      controls.start("hidden");
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [controls, inView, isHovering]);

  return (
    <Box
      id="process"
      sx={{
        py: { xs: 8, md: 12 },
        background: 'linear-gradient(135deg, #0a0a23 0%, #1a1a40 50%, #2d1b69 100%)',
        color: 'white',
        position: 'relative',
        overflow: 'hidden',
      }}
      ref={ref}
    >
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          pointerEvents: 'none',
          zIndex: 0
        }}
      >
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            style={{
              position: 'absolute',
              width: Math.random() * 8 + 4,
              height: Math.random() * 8 + 4,
              borderRadius: '50%',
              background: commonGradients[i % commonGradients.length],
              opacity: 0.3,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              x: [0, Math.random() * 200 - 100],
              y: [0, Math.random() * 200 - 100],
              scale: [1, Math.random() + 0.5, 1],
            }}
            transition={{
              duration: 10 + Math.random() * 20,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        ))}
      </Box>

      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Box sx={{ textAlign: "center", mb: 8 }}>
          <FadeIn>
            <Typography
              variant="h6"
              fontWeight="bold"
              color="primary.main"
              sx={{ mb: 2 }}
            >
              OUR PROCESS
            </Typography>
            <GradientText variant="h2" fontWeight="bold" sx={{ mb: 3 }}>
              How We Streamline Your Expenses
            </GradientText>
            <Typography
              variant="body1"
              color="rgba(255, 255, 255, 0.8)"
              sx={{
                maxWidth: "800px",
                mx: "auto",
              }}
            >
              Our structured approach ensures seamless implementation of automated expense management solutions tailored to your business.
            </Typography>
          </FadeIn>
        </Box>

        <Grid container spacing={6} alignItems="center">
          <Grid item xs={12} md={6}>
            <FadeIn>
              <Stepper activeStep={activeStep} orientation="vertical">
                {steps.map((step, index) => (
                  <Step
                    key={step.label}
                    completed={index < activeStep}
                    onMouseEnter={() => handleStepMouseEnter(index)}
                    onMouseLeave={handleStepMouseLeave}
                    sx={{
                      cursor: 'pointer',
                      '&:hover': {
                        '& .MuiStepLabel-label': {
                          color: 'primary.main',
                        },
                      },
                    }}
                  >
                    <StepLabel
                      StepIconProps={{
                        sx: {
                          color:
                            index === activeStep ? "primary.main" : "grey.400",
                          "& .MuiStepIcon-text": {
                            fill: index === activeStep ? "white" : "grey.600",
                          },
                          transition: 'all 0.3s ease',
                        },
                      }}
                    >
                      <Typography 
                        variant="h6" 
                        fontWeight="bold"
                        sx={{
                          transition: 'color 0.3s ease',
                          color: 'white'
                        }}
                      >
                        Step {index + 1}: {step.label}
                      </Typography>
                    </StepLabel>
                    <StepContent>
                      <Typography
                        variant="body1"
                        color="rgba(255, 255, 255, 0.8)"
                        sx={{ mb: 2, mt: 1 }}
                      >
                        {step.description}
                      </Typography>
                    </StepContent>
                  </Step>
                ))}
              </Stepper>
            </FadeIn>
          </Grid>

          <Grid item xs={12} md={6}>
            <FadeIn delay={0.2}>
              <Card
                elevation={0}
                sx={{
                  borderRadius: 4,
                  overflow: "hidden",
                  background:
                    "linear-gradient(135deg, #4E36FF 0%, #900BFF 100%)",
                }}
              >
                <CardContent sx={{ p: 4, color: "white", textAlign: "center" }}>
                  <Typography variant="h4" fontWeight="bold" sx={{ mb: 4 }}>
                    Start Automating Your Expenses Today!
                  </Typography>

                  <Grid container spacing={3}>
                    <Grid item xs={12} sm={4}>
                      <motion.div
                        whileHover={{ y: -10 }}
                        transition={{ duration: 0.3 }}
                      >
                        <Box
                          sx={{
                            p: 3,
                            borderRadius: 2,
                            bgcolor: "rgba(255,255,255,0.1)",
                            height: "100%",
                          }}
                        >
                          <Typography
                            variant="h6"
                            fontWeight="bold"
                            sx={{ mb: 2 }}
                          >
                            Book a Free Demo
                          </Typography>
                          <Typography variant="body2" sx={{ opacity: 0.9 }}>
                            Experience how Expenses Suite can transform your financial processes.
                          </Typography>
                        </Box>
                      </motion.div>
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <motion.div
                        whileHover={{ y: -10 }}
                        transition={{ duration: 0.3 }}
                      >
                        <Box
                          sx={{
                            p: 3,
                            borderRadius: 2,
                            bgcolor: "rgba(255,255,255,0.1)",
                            height: "100%",
                          }}
                        >
                          <Typography
                            variant="h6"
                            fontWeight="bold"
                            sx={{ mb: 2 }}
                          >
                            Consult Our Experts
                          </Typography>
                          <Typography variant="body2" sx={{ opacity: 0.9 }}>
                            Get a tailored expense management strategy for your business.
                          </Typography>
                        </Box>
                      </motion.div>
                    </Grid>

                    <Grid item xs={12} sm={4}>
                      <motion.div
                        whileHover={{ y: -10 }}
                        transition={{ duration: 0.3 }}
                      >
                        <Box
                          sx={{
                            p: 3,
                            borderRadius: 2,
                            bgcolor: "rgba(255,255,255,0.1)",
                            height: "100%",
                          }}
                        >
                          <Typography
                            variant="h6"
                            fontWeight="bold"
                            sx={{ mb: 2 }}
                          >
                            Simplify Your Finances
                          </Typography>
                          <Typography variant="body2" sx={{ opacity: 0.9 }}>
                            Reduce errors, save time, and boost efficiency with automation.
                          </Typography>
                        </Box>
                      </motion.div>
                    </Grid>
                  </Grid>

                  <Box sx={{ mt: 4 }}>
                    <Typography variant="body1">
                      📞 Call Us: +91 9302075637
                    </Typography>

                    <Link href="mailto:fintech@fincoopers.in" style={{ textDecoration: 'none' }}>
                      <Typography variant="body1" sx={{color: 'white'}}>
                        📧 Email: fintech@fincoopers.in
                      </Typography>
                    </Link>
                  </Box>
                </CardContent>
              </Card>
            </FadeIn>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default ProcessSection;