'use client';
import React, { useState, useEffect } from 'react';
import {
  AppBar,
  Box,
  Button,
  Container,
  Drawer,
  IconButton,
  List,
  ListItem,
  Toolbar,
  Typography,
  useScrollTrigger,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import Link from 'next/link';
import { motion } from 'framer-motion';

const navItems = [
  { name: 'Home', href: '/' },
  { name: 'Features', href: '/features' },
  { name: 'Contact', href: '/contact' },
];

function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const trigger = useScrollTrigger({
    disableHysteresis: true,
    threshold: 50,
  });

  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  return (
    <>
      <AppBar 
        position="fixed" 
        elevation={0}
        sx={{
          background: scrolled 
            ? 'linear-gradient(135deg, rgba(10, 10, 35, 0.95) 0%, rgba(26, 26, 64, 0.95) 50%, rgba(45, 27, 105, 0.95) 100%)'
            : 'transparent',
          backdropFilter: scrolled ? 'blur(10px)' : 'none',
          boxShadow: scrolled 
            ? '0 4px 20px rgba(0, 0, 0, 0.3)' 
            : 'none',
          transition: 'all 0.3s ease',
          color: 'white',
          zIndex: 1200
        }}
      >
        <Container maxWidth="xl">
          <Toolbar disableGutters sx={{ py: 1 }}>
            <Link href="/" passHref>
              <motion.div
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.2 }}
                style={{ cursor: 'pointer' }}
              >
                <Typography
                  variant="h5"
                  component="div"
                  sx={{
                    fontWeight: 800,
                    fontSize: { xs: '1.5rem', md: '1.8rem' },
                    background: scrolled 
                      ? 'linear-gradient(135deg, #64b5f6 0%, #42a5f5 25%, #2196f3 50%, #1976d2 75%, #0d47a1 100%)'
                      : 'linear-gradient(135deg, #ffffff 0%, #e3f2fd 25%, #bbdefb 50%, #90caf9 75%, #64b5f6 100%)',
                    backgroundClip: 'text',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    textShadow: scrolled ? 'none' : '0 2px 4px rgba(0,0,0,0.3)',
                    transition: 'all  | 0.3s ease',
                    mr: 2,
                    letterSpacing: '-0.5px',
                  }}
                >
                  Expenses Suite
                </Typography>
              </motion.div>
            </Link>
            
            <Box sx={{ flexGrow: 1 }} />
            
            <Box sx={{ display: { xs: 'none', md: 'flex' } }}>
              {navItems.map((item) => (
                <Link href={item.href} key={item.name} passHref>
                  <motion.div
                    whileHover={{ y: -3 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Button
                      sx={{
                        mx: 1,
                        color: 'white',
                        '&:hover': {
                          background: 'transparent',
                          color: 'rgba(255,255,255,0.8)',
                        },
                      }}
                    >
                      {item.name}
                    </Button>
                  </motion.div>
                </Link>
              ))}
            </Box>
            
            <Box sx={{ display: { xs: 'flex', md: 'none' } }}>
              <IconButton
                color="inherit"
                aria-label="open drawer"
                edge="end"
                onClick={handleDrawerToggle}
              >
                <MenuIcon />
              </IconButton>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
      
      <Drawer
        anchor="right"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{ keepMounted: true }}
        sx={{
          '& .MuiDrawer-paper': { 
            width: '100%', 
            maxWidth: 300,
            background: 'linear-gradient(135deg, #0a0a23 0%, #1a1a40 50%, #2d1b69 100%)',
          },
        }}
      >
        <Box sx={{ p: 2, display: 'flex', justifyContent: 'flex-end' }}>
          <IconButton onClick={handleDrawerToggle} sx={{ color: 'white' }}>
            <CloseIcon />
          </IconButton>
        </Box>
        <List>
          {navItems.map((item) => (
            <ListItem key={item.name} disablePadding>
              <Link 
                href={item.href} 
                passHref 
                style={{ width: '100%', textDecoration: 'none' }}
                onClick={handleDrawerToggle}
              >
                <motion.div
                  whileHover={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    x: 5,
                    transition: { duration: 0.2 }
                  }}
                  style={{ width: '100%' }}
                >
                  <Button 
                    fullWidth
                    sx={{ 
                      py: 2, 
                      justifyContent: 'flex-start', 
                      pl: 4,
                      color: 'white',
                      '&:hover': {
                        backgroundColor: 'transparent',
                        color: 'rgba(255,255,255,0.8)',
                      }
                    }}
                  >
                    {item.name}
                  </Button>
                </motion.div>
              </Link>
            </ListItem>
          ))}
        </List>
      </Drawer>
    </>
  );
}

export default Navbar;